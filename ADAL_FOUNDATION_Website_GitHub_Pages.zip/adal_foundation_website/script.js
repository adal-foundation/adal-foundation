const menuButton = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');
if (menuButton && navLinks) {
  menuButton.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(isOpen));
    menuButton.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
  });
  navLinks.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-label', 'Open navigation');
  }));
}
document.getElementById('year').textContent = new Date().getFullYear();

const topButton = document.querySelector('.back-to-top');
window.addEventListener('scroll', () => {
  topButton.classList.toggle('visible', window.scrollY > 500);
}, { passive: true });
topButton.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

const form = document.getElementById('volunteer-form');
form.addEventListener('submit', (event) => {
  event.preventDefault();
  if (!form.reportValidity()) return;
  const data = new FormData(form);
  const subject = encodeURIComponent('ADAL FOUNDATION — Website enquiry');
  const body = encodeURIComponent(
    `Name: ${data.get('name')}\nEmail: ${data.get('email')}\nPhone: ${data.get('phone') || 'Not provided'}\nLocation: ${data.get('location') || 'Not provided'}\nArea of interest: ${data.get('interest') || 'Not specified'}\n\nMessage:\n${data.get('message')}`
  );
  // Replace the placeholder below with the foundation's verified email address.
  const recipient = 'YOUR-EMAIL@example.com';
  if (recipient === 'YOUR-EMAIL@example.com') {
    document.getElementById('form-note').textContent =
      'The form is ready. Add your verified foundation email in script.js (recipient variable) before publishing to enable email preparation.';
    return;
  }
  window.location.href = `mailto:${recipient}?subject=${subject}&body=${body}`;
});

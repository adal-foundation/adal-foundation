# ADAL FOUNDATION website

A responsive static website built for GitHub Pages.

## Publish on GitHub Pages
1. Create a GitHub repository (for example, `adal-foundation`).
2. Upload the contents of this folder. `index.html` must be in the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Your site will be available at `https://YOUR-USERNAME.github.io/adal-foundation/` after deployment.

## Before publishing
- In `script.js`, replace `YOUR-EMAIL@example.com` with an email address controlled by the foundation.
- Add verified phone/social links only if you want them displayed. The current site intentionally does not invent contact details.
- The contact form uses the visitor's email application (`mailto:`); it does not save submissions to a database. A backend or trusted form service is needed for online form storage.
- The donation section is intentionally informational only; no payment gateway or donation account is configured.
- The site accurately states that ADAL FOUNDATION is currently an unregistered initiative. Update this only after registration and legal verification.

## Files
- `index.html` — page content
- `style.css` — responsive design
- `script.js` — mobile navigation, back-to-top, and enquiry form behaviour
- `assets/favicon.svg` — site icon
